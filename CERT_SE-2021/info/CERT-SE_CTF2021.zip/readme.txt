CERT-SE CTF 2021
 
Även i år har CERT-SE en utmaning under cybersäkerhetsmånaden. Denna utmaning vänder sig till alla med IT-säkerhetsintresse.
 
<scenario>
CERT-SE har kommit över nätverkstrafik från den fiktiva hackergruppen ”Medelålders Sura Blackhats”.
Kan du hitta alla flaggorna?
</scenario>
 
I ZIP-filen under finns en nätverksdump (PCAP) som innehåller totalt sex stycken flaggor, dessa har formatet ”CTF[***********]”.
 
När du känner att du hittat så många flaggor du kan så får du gärna maila oss dessa samt en beskrivning av hur du löst de olika uppgifterna till cert@cert.se, skriv ”CTF2021” i ärenderaden för mailet. Snabbast, flest flaggor och bäst beskrivning premieras.
 
OBS, vi kommer bara acceptera ett svar per person så se till att hitta så många flaggor som möjligt innan du skickar in. Sista dagen att skicka in svar är 31/10-2021.
 
-

CERT-SE CTF 2021
This year, too, CERT-SE has a challenge during the cyber security month. This challenge is aimed at anyone with an interest in IT security.

<scenario> CERT-SE has come across network traffic from the fictional hacker group "Medelålders Sura Blackhats".
Can you find all the flags?
</scenario>

In the ZIP file below there is a network dump (PCAP) that contains a total of six flags, these have the format "CTF [***********]".

When you feel that you have found as many flags as you can, feel free to email us these and a description of how you solved the various tasks to cert@cert.se, write "CTF2021" as the subject of the email. Fastest, most flags and best descriptions are awarded.

NOTE, we will only accept one response per person so be sure to find as many flags as possible before submitting. The last day to send in answers is 31:st October 2021.
